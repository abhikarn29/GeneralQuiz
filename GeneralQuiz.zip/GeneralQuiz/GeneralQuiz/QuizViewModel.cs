﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace GeneralQuiz
{
    public class QuizViewModel : INotifyPropertyChanged
    {
        #region Private Variables
        private string correctanswer;
        private Quiz q = new Quiz();
        private List<int> lst = new List<int>();
        private string ans;
        private int score = 0;
        private int number = 1;
        private ICommand startQuiz;
        private ICommand option1;
        private ICommand option2;
        private ICommand option3;
        private ICommand option4;
        private ICommand optionClick;
        private ICommand submit;
        private ICommand review;
        private bool answer1;
        private bool restart;
        private bool score1;
        private bool final;
        private string question;
        private string ans1;
        private string ans2;
        private string ans3;
        private string ans4;
        private bool startButtonVisibility;
        private bool option1Enabled;
        private bool option2Enabled;
        private bool option3Enabled;
        private bool option4Enabled;

        private bool enabled1;
        private bool enabled2;
        private bool enabled3;
        private bool enabled4;
        private bool enabled5;
        private bool enabled6;
        private bool enabled8;
        private bool enabled9;
        private bool enabled7;
        private bool enabled10;




        private bool userTxtBox;
        private bool lblUsername;
        private string usernametext;
        private string session;
        private bool sessionVisi;
        private string finalContent;
        private Color color1;
        private Color color2;
        private Color color3;
        private Color color4;
        private Color color5;
        private Color color6;
        private Color color7;
        private Color color8;
        private Color color9;
        private Color color10;
        private Dictionary<int, int> ReviewQuestion;
        private bool qustNo;
        private bool test;

        private bool reviewans;

        #endregion

        #region Events
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Constructor
        public QuizViewModel()
        {
            StartQuiz = new RelayCommand(new Action<object>(Button_Click));
            Option1 = new RelayCommand(new Action<object>(ans1_Click));
            Option2 = new RelayCommand(new Action<object>(ans2_Click));
            Option3 = new RelayCommand(new Action<object>(ans3_Click));
            Option4 = new RelayCommand(new Action<object>(ans4_Click));
            OptionClick = new RelayCommand(new Action<object>(OptionBtnClick));
            Submit = new RelayCommand(new Action<object>(SubmitBtnClick));
            Review = new RelayCommand(new Action<object>(ReviewBtnClick));
            LblUsername = true;
            UserTxtBox1 = true;
            SessionVisi = true;
            Answer1 = false;
            Restart = false;
            Score1 = false;
            Final = false;
            StartButtonVisibility = true;
            ReviewQuestion = new Dictionary<int, int>();
            QustNo = false;
        }
        #endregion

        #region Property


        public ICommand OptionClick { get => optionClick; set => optionClick = value; }
        public ICommand StartQuiz
        {
            get
            {
                return startQuiz;
            }
            set
            {
                startQuiz = value;
                OnPropertyRaised("StartQuiz");
            }
        }

        public ICommand Option1
        {
            get
            {
                return option1;
            }
            set
            {
                option1 = value;
                OnPropertyRaised("Option1");
            }
        }
        public ICommand Option2
        {
            get
            {
                return option2;
            }
            set
            {
                option2 = value;
                OnPropertyRaised("Option2");
            }
        }
        public ICommand Option3
        {
            get
            {
                return option3;
            }
            set
            {
                option3 = value;
                OnPropertyRaised("Option3");
            }
        }
        public ICommand Option4
        {
            get
            {
                return option4;
            }
            set
            {
                option4 = value;
                OnPropertyRaised("Option4");
            }
        }
        public bool Answer1
        {
            get
            {
                return answer1;
            }
            set
            {
                answer1 = value;
                OnPropertyRaised("Answer1");
            }
        }
        public bool Restart
        {
            get
            {
                return restart;
            }
            set
            {
                restart = value;
                OnPropertyRaised("Restart");
            }
        }
        public bool Score1
        {
            get
            {
                return score1;
            }
            set
            {
                score1 = value;
                OnPropertyRaised("Score1");
            }
        }
        public bool Final
        {
            get
            {
                return final;
            }
            set
            {
                final = value;
                OnPropertyRaised("Final");
            }
        }

        public string FinalContent
        {
            get
            {
                return finalContent;
            }
            set
            {
                finalContent = value;
                OnPropertyRaised("FinalContent");
            }
        }


        public string Question
        {
            get
            {
                return question;
            }
            set
            {
                question = value;
                OnPropertyRaised("Question");
            }
        }
        public string Ans1
        {
            get
            {
                return ans1;
            }
            set
            {
                ans1 = value;
                OnPropertyRaised("Ans1");
            }
        }

        public string Ans2
        {
            get
            {
                return ans2;
            }
            set
            {
                ans2 = value;
                OnPropertyRaised("Ans2");
            }
        }

        public string Ans3
        {
            get
            {
                return ans3;
            }
            set
            {
                ans3 = value;
                OnPropertyRaised("Ans3");
            }
        }

        public string Ans4
        {
            get
            {
                return ans4;
            }
            set
            {
                ans4 = value;
                OnPropertyRaised("Ans4");
            }
        }

        public bool StartButtonVisibility
        {
            get
            {
                return startButtonVisibility;
            }
            set
            {
                startButtonVisibility = value;
                OnPropertyRaised("StartButtonVisibility");
            }
        }

        public ICommand Submit { get => submit; set => submit = value; }

        public ICommand Review { get => review; set => review = value; }
        public bool Option1Enabled
        {
            get
            {
                return option1Enabled;
            }
            set
            {
                option1Enabled = value;
                OnPropertyRaised("Option1Enabled");
            }
        }
        public bool Option2Enabled
        {
            get
            {
                return option2Enabled;
            }
            set
            {
                option2Enabled = value;
                OnPropertyRaised("Option2Enabled");
            }
        }

        public bool Option3Enabled
        {
            get
            {
                return option3Enabled;
            }
            set
            {
                option3Enabled = value;
                OnPropertyRaised("Option3Enabled");
            }
        }

        public bool Option4Enabled
        {
            get
            {
                return option4Enabled;
            }
            set
            {
                option4Enabled = value;
                OnPropertyRaised("Option4Enabled");
            }
        }

        public bool Enabled1
        {
            get
            {
                return enabled1;
            }
            set
            {
                enabled1 = value;
                OnPropertyRaised("Enabled1");
            }
        }

        public bool Enabled2
        {
            get
            {
                return enabled2;
            }
            set
            {
                enabled2 = value;
                OnPropertyRaised("Enabled2");
            }
        }

        public bool Enabled3
        {
            get
            {
                return enabled3;
            }
            set
            {
                enabled3 = value;
                OnPropertyRaised("Enabled3");
            }
        }

        public bool Enabled4
        {
            get
            {
                return enabled4;
            }
            set
            {
                enabled4 = value;
                OnPropertyRaised("Enabled4");
            }
        }

        public bool Enabled5
        {
            get
            {
                return enabled5;
            }
            set
            {
                enabled5 = value;
                OnPropertyRaised("Enabled5");
            }
        }

        public bool Enabled6
        {
            get
            {
                return enabled6;
            }
            set
            {
                enabled6 = value;
                OnPropertyRaised("Enabled6");
            }
        }

        public bool Enabled7
        {
            get
            {
                return enabled7;
            }
            set
            {
                enabled7 = value;
                OnPropertyRaised("Enabled7");
            }
        }

        public bool Enabled8
        {
            get
            {
                return enabled8;
            }
            set
            {
                enabled8 = value;
                OnPropertyRaised("Enabled8");
            }
        }

        public bool Enabled9
        {
            get
            {
                return enabled9;
            }
            set
            {
                enabled9 = value;
                OnPropertyRaised("Enabled9");
            }
        }


        public bool Enabled10
        {
            get
            {
                return enabled10;
            }
            set
            {
                enabled10 = value;
                OnPropertyRaised("Enabled10");
            }
        }


        public Color Color10
        {
            get
            {
                return color10;
            }
            set
            {
                color10 = value;
                OnPropertyRaised("Color10");
            }
        }

        public Color Color9
        {
            get
            {
                return color9;
            }
            set
            {
                color9 = value;
                OnPropertyRaised("Color9");
            }
        }

        public Color Color8
        {
            get
            {
                return color8;
            }
            set
            {
                color8 = value;
                OnPropertyRaised("Color8");
            }
        }

        public Color Color7
        {
            get
            {
                return color7;
            }
            set
            {
                color7 = value;
                OnPropertyRaised("Color7");
            }
        }

        public Color Color6
        {
            get
            {
                return color6;
            }
            set
            {
                color6 = value;
                OnPropertyRaised("Color6");
            }
        }

        public Color Color5
        {
            get
            {
                return color5;
            }
            set
            {
                color5 = value;
                OnPropertyRaised("Color5");
            }
        }

        public Color Color4
        {
            get
            {
                return color4;
            }
            set
            {
                color4 = value;
                OnPropertyRaised("Color4");
            }
        }

        public Color Color3
        {
            get
            {
                return color3;
            }
            set
            {
                color3 = value;
                OnPropertyRaised("Color3");
            }
        }

        public Color Color2
        {
            get
            {
                return color2;
            }
            set
            {
                color2 = value;
                OnPropertyRaised("Color2");
            }
        }

        public Color Color1
        {
            get
            {
                return color1;
            }
            set
            {
                color1 = value;
                OnPropertyRaised("Color1");
            }
        }

        public bool UserTxtBox1
        {
            get
            {
                return userTxtBox;
            }
            set
            {
                userTxtBox = value;
                OnPropertyRaised("UserTxtBox1");
            }
        }
        public bool LblUsername
        {
            get
            {
                return lblUsername;
            }
            set
            {
                lblUsername = value;
                OnPropertyRaised("LblUsername");
            }
        }

        public string Usernametext
        {
            get
            {
                return usernametext;
            }
            set
            {
                usernametext = value;
                OnPropertyRaised("Usernametext");
            }
        }

        public string Session
        {
            get
            {
                return session;
            }
            set
            {
                session = value;
                OnPropertyRaised("Session");
            }
        }

        public bool SessionVisi
        {
            get
            {
                return sessionVisi;
            }
            set
            {
                sessionVisi = value;
                OnPropertyRaised("SessionVisi");
            }
        }


        public bool QustNo
        {
            get
            {
                return qustNo;
            }
            set
            {
                qustNo = value;
                OnPropertyRaised("QustNo");
            }
        }

        #endregion

        #region private Methods

        private void OptionBtnClick(object obj)
        {
            if (correctanswer != null|| !test)
            {
                test = true;
                int i = Convert.ToInt32(obj);
                Question = q.getQuestion(i);
                Ans1 = q.getAnswer(i, 1);
                Ans2 = q.getAnswer(i, 2);
                Ans3 = q.getAnswer(i, 3);
                Ans4 = q.getAnswer(i, 4);
                lst.Add(i);
                if (Convert.ToString(Ans1).StartsWith("*"))
                {
                    this.ans = Convert.ToString(Ans1).Substring(1, Convert.ToString(Ans1).Length - 1);
                    Ans1 = Convert.ToString(Ans1).Substring(1, Convert.ToString(Ans1).Length - 1);
                }
                else
                {
                    if (Convert.ToString(Ans2).StartsWith("*"))
                    {
                        this.ans = Convert.ToString(Ans2).Substring(1, Convert.ToString(Ans2).Length - 1);
                        Ans2 = Convert.ToString(Ans2).Substring(1, Convert.ToString(Ans2).Length - 1);
                    }
                    else
                    {
                        if (Convert.ToString(Ans3).StartsWith("*"))
                        {
                            this.ans = Convert.ToString(Ans3).Substring(1, Convert.ToString(Ans3).Length - 1);
                            Ans3 = Convert.ToString(Ans3).Substring(1, Convert.ToString(Ans3).Length - 1);
                        }
                        else
                        {
                            this.ans = Convert.ToString(Ans4).Substring(1, Convert.ToString(Ans4).Length - 1);
                            Ans4 = Convert.ToString(Ans4).Substring(1, Convert.ToString(Ans4).Length - 1);
                        }
                    }
                }
                MarkForReview1(i);
            }
            
        }



        private void MarkForReview1(int a)
        {

            switch (a)
            {
                case 1:
                    Enabled1 = false;
                    //Color1 = Color.FromRgb(52, 149, 235);
                    break;
                case 2:
                    Enabled2 = false;
                    //Color2 = Color.FromRgb(52, 149, 235);
                    break;
                case 3:
                    Enabled3 = false;
                    //Color3 = Color.FromRgb(52, 149, 235);
                    break;
                case 4:
                    Enabled4 = false;
                    //Color4 = Color.FromRgb(52, 149, 235);
                    break;
                case 5:
                    Enabled5 = false;
                    //Color5 = Color.FromRgb(52, 149, 235);
                    break;
                case 6:
                    Enabled6 = false;
                    //Color6 = Color.FromRgb(52, 149, 235);
                    break;
                case 7:
                    Enabled7 = false;
                    // Color7 = Color.FromRgb(52, 149, 235);
                    break;
                case 8:
                    Enabled8 = false;
                    //Color8 = Color.FromRgb(52, 149, 235);
                    break;
                case 9:
                    Enabled9 = false;
                    //Color9 = Color.FromRgb(52, 149, 235);
                    break;
                case 10:
                    Enabled10 = false;

                    break;
            }
        }

        private void ReviewBtnClick(object obj)
        {
            Option1Enabled = true;
            Option2Enabled = true;
            Option3Enabled = true;
            Option4Enabled = true;
            
            MarkForReview();
            QuestionSelection();
            correctanswer = null;
        }


        private void MarkForReview()
        {
            int a = number ;
            switch (a)
            {
                case 1:
                    Enabled1 = true;
                    Color1 = Color.FromRgb(52, 149, 235);
                    break;
                case 2:
                    Enabled2 = true;
                    Color2 = Color.FromRgb(52, 149, 235);
                    break;
                case 3:
                    Enabled3 = true;
                    Color3 = Color.FromRgb(52, 149, 235);
                    break;
                case 4:
                    Enabled4 = true;
                    Color4 = Color.FromRgb(52, 149, 235);
                    break;
                case 5:
                    Enabled5 = true;
                    Color5 = Color.FromRgb(52, 149, 235);
                    break;
                case 6:
                    Enabled6 = true;
                    Color6 = Color.FromRgb(52, 149, 235);
                    break;
                case 7:
                    Enabled7 = true;
                    Color7 = Color.FromRgb(52, 149, 235);
                    break;
                case 8:
                    Enabled8 = true;
                    Color8 = Color.FromRgb(52, 149, 235);
                    break;
                case 9:
                    Enabled9 = true;
                    Color9 = Color.FromRgb(52, 149, 235);
                    break;
                case 10:
                    Enabled10 = true;
                    Color10 = Color.FromRgb(52, 149, 235);
                    break;
            }
        }

        private void QuestionSelection()
        {
            if (this.number < 11 || test)
            {
                if (!test)
                {
                    this.number++;
                }

                int i = this.getRandom();
                Question = q.getQuestion(i);
                //
                Ans1 = q.getAnswer(i, 1);
                Ans2 = q.getAnswer(i, 2);
                Ans3 = q.getAnswer(i, 3);
                Ans4 = q.getAnswer(i, 4);
                lst.Add(i);
                if (Convert.ToString(Ans1).StartsWith("*"))
                {
                    this.ans = Convert.ToString(Ans1).Substring(1, Convert.ToString(Ans1).Length - 1);
                    Ans1 = Convert.ToString(Ans1).Substring(1, Convert.ToString(Ans1).Length - 1);
                }
                else
                {
                    if (Convert.ToString(Ans2).StartsWith("*"))
                    {
                        this.ans = Convert.ToString(Ans2).Substring(1, Convert.ToString(Ans2).Length - 1);
                        Ans2 = Convert.ToString(Ans2).Substring(1, Convert.ToString(Ans2).Length - 1);
                    }
                    else
                    {
                        if (Convert.ToString(Ans3).StartsWith("*"))
                        {
                            this.ans = Convert.ToString(Ans3).Substring(1, Convert.ToString(Ans3).Length - 1);
                            Ans3 = Convert.ToString(Ans3).Substring(1, Convert.ToString(Ans3).Length - 1);
                        }
                        else
                        {
                            this.ans = Convert.ToString(Ans4).Substring(1, Convert.ToString(Ans4).Length - 1);
                            Ans4 = Convert.ToString(Ans4).Substring(1, Convert.ToString(Ans4).Length - 1);
                        }
                    }
                }
                if (!ReviewQuestion.ContainsKey(number - 1))
                {
                    ReviewQuestion.Add(number - 1, i);
                }
            }
            else
            {
                if (Enabled1 || Enabled2 || Enabled3 || Enabled4 || Enabled5 || Enabled6 || Enabled7 || Enabled8 || Enabled9 || Enabled10)
                {
                    MessageBox.Show("Please complete the question which are kept for reviewing . NOTE : You are only allowed to submit the reviewed Question");
                }
                else
                {
                    Answer1 = false;
                    QustNo = false;
                    Final = true;
                    FinalContent = "         Date :" + System.DateTime.Now + "\n          Your score is : " + this.score + "\n";
                }
            }
        }



        private void OnPropertyRaised(string propertyname)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
            }
        }



        private void Button_Click(object obj)
        {
            if (Usernametext != null && Usernametext != string.Empty)
            {

                StartButtonVisibility = false;
                Answer1 = true;
                LblUsername = false;
                UserTxtBox1 = false;
                Session = "Welcome :" + Usernametext;
                sessionVisi = true;
                QustNo = true;
                //scoreLbl.Visibility = Visibility.Visible;
                //
                int i = this.getRandom();
                Question = q.getQuestion(i);
                //
                Ans1 = q.getAnswer(i, 1);
                Ans2 = q.getAnswer(i, 2);
                Ans3 = q.getAnswer(i, 3);
                Ans4 = q.getAnswer(i, 4);
                Option1Enabled = true;
                Option2Enabled = true;
                Option3Enabled = true;
                Option4Enabled = true;
                if (Convert.ToString(Ans1).StartsWith("*"))
                {
                    this.ans = Convert.ToString(Ans1).Substring(1, Convert.ToString(Ans1).Length - 1);
                    Ans1 = Convert.ToString(Ans1).Substring(1, Convert.ToString(Ans1).Length - 1);
                }
                else
                {
                    if (Convert.ToString(Ans2).StartsWith("*"))
                    {
                        this.ans = Convert.ToString(Ans2).Substring(1, Convert.ToString(Ans2).Length - 1);
                        Ans2 = Convert.ToString(Ans2).Substring(1, Convert.ToString(Ans2).Length - 1);
                    }
                    else
                    {
                        if (Convert.ToString(Ans3).StartsWith("*"))
                        {
                            this.ans = Convert.ToString(Ans3).Substring(1, Convert.ToString(Ans3).Length - 1);
                            Ans3 = Convert.ToString(Ans3).Substring(1, Convert.ToString(Ans3).Length - 1);
                        }
                        else
                        {
                            this.ans = Convert.ToString(Ans4).Substring(1, Convert.ToString(Ans4).Length - 1);
                            Ans4 = Convert.ToString(Ans4).Substring(1, Convert.ToString(Ans4).Length - 1);
                        }
                    }
                }


                lst.Add(i);
            }
        }

        private void SubmitBtnClick(object obj)
        {
            if (correctanswer == this.ans)
            {
                this.score++;
            }
            Option1Enabled = true;
            Option2Enabled = true;
            Option3Enabled = true;
            Option4Enabled = true;
            if (correctanswer != null)
            {
                QuestionSelection();
                test = false;
            }
            

            correctanswer = null;
            


        }

        private void ans1_Click(object obj)
        {
            Option1Enabled = false;
            Option2Enabled = true;
            Option3Enabled = true;
            Option4Enabled = true;
            correctanswer = Convert.ToString(Ans1);
            //if (Convert.ToString(Ans1) == this.ans)
            //    this.score++;

        }

        private void ans2_Click(object obj)
        {
            Option1Enabled = true;
            Option2Enabled = false;
            Option3Enabled = true;
            Option4Enabled = true;
            correctanswer = Convert.ToString(Ans2);


        }

        private void ans3_Click(object obj)
        {
            Option1Enabled = true;
            Option2Enabled = true;
            Option3Enabled = false;
            Option4Enabled = true;
            correctanswer = Convert.ToString(Ans3);

            //if (Convert.ToString(Ans3) == this.ans)
            //    this.score++;

        }

        private void ans4_Click(object obj)
        {
            Option1Enabled = true;
            Option2Enabled = true;
            Option3Enabled = true;
            Option4Enabled = false;
            correctanswer = Convert.ToString(Ans4);

            //if (Convert.ToString(Ans4) == this.ans)
            //    this.score++;

        }
        #endregion

        #region Public Method
        public int getRandom()
        {
            Random rnd = new Random();
            int i = rnd.Next(11);
            if (lst.Contains(i) && lst.Count() < 11)
                while (lst.Contains(i))
                    i = rnd.Next(0, 11);
            return i;
        }
        #endregion
    }
}
