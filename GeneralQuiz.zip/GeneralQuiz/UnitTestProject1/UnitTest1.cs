﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using GeneralQuiz;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {


        [TestMethod]
        public void TestMethod1()
        {
            PrivateObject obj = new PrivateObject(typeof(QuizViewModel));
            obj.Invoke("OptionBtnClick");
            bool actual = (bool)obj.GetField("test");
            Assert.AreEqual(true, actual);
        }

       
    }
}
